#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MusicPlayerSDK::MusicInstrument" for configuration "Release"
set_property(TARGET MusicPlayerSDK::MusicInstrument APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MusicPlayerSDK::MusicInstrument PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libMusicInstrument.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/libMusicInstrument.dll"
  )

list(APPEND _cmake_import_check_targets MusicPlayerSDK::MusicInstrument )
list(APPEND _cmake_import_check_files_for_MusicPlayerSDK::MusicInstrument "${_IMPORT_PREFIX}/lib/libMusicInstrument.dll.a" "${_IMPORT_PREFIX}/bin/libMusicInstrument.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
