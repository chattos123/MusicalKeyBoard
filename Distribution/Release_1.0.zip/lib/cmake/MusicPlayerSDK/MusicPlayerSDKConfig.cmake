
include(CMakeFindDependencyMacro)
if(WIN32)
    # Win32 dependencies linked privately in target definitions
elseif(UNIX)
    find_dependency(Threads)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/MusicPlayerSystemTargets.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/MusicInstrumentTargets.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/MusicBuilderBLTargets.cmake")
