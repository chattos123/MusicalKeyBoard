#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MusicPlayerSDK::MusicPlayerSystem" for configuration "Release"
set_property(TARGET MusicPlayerSDK::MusicPlayerSystem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MusicPlayerSDK::MusicPlayerSystem PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libMusicPlayerSystem.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/libMusicPlayerSystem.dll"
  )

list(APPEND _cmake_import_check_targets MusicPlayerSDK::MusicPlayerSystem )
list(APPEND _cmake_import_check_files_for_MusicPlayerSDK::MusicPlayerSystem "${_IMPORT_PREFIX}/lib/libMusicPlayerSystem.dll.a" "${_IMPORT_PREFIX}/bin/libMusicPlayerSystem.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
